const reviewData = require('./reviews');
const bookData = require('./books');

module.exports = {
  books: bookData,
  reviews: reviewData
};
