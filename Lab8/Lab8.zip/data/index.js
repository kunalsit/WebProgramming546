module.exports = {
    getshows: require("./getshows")
  };
  